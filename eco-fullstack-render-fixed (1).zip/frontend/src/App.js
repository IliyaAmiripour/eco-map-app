import React from "react";

function App() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>EcoMap Frontend 🌍</h1>
      <p>This is the frontend running on Render 🚀</p>
    </div>
  );
}

export default App;
